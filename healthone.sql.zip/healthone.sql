-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 11 jan 2022 om 15:31
-- Serverversie: 10.4.21-MariaDB
-- PHP-versie: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthone`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `categories`
--

CREATE TABLE `categories` (
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `categories`
--

INSERT INTO `categories` (`name`, `image`, `id`) VALUES
('roeitrainer', '/img/categories/roeitrainer.jpg', 1),
('hometrainer', '/img/categories/hometrainer.jpg', 2),
('crosstrainer', '/img/categories/crosstrainer.jpg', 3),
('loopband', '/img/categories/loopband.jpg', 4);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `opening_times`
--

CREATE TABLE `opening_times` (
  `open_time` time NOT NULL,
  `day` varchar(255) NOT NULL,
  `id` int(11) NOT NULL,
  `close_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `opening_times`
--

INSERT INTO `opening_times` (`open_time`, `day`, `id`, `close_time`) VALUES
('07:00:00', 'Maandag', 1, '20:00:00'),
('08:00:00', 'Dinsdag', 2, '20:00:00'),
('07:00:00', 'Woensdag', 3, '20:00:00'),
('08:00:00', 'Donderdag', 4, '20:00:00'),
('07:00:00', 'Vrijdag', 5, '20:30:00'),
('08:00:00', 'Zaterdag', 6, '13:00:00'),
('08:00:00', 'Zondag', 7, '13:00:00');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `products`
--

CREATE TABLE `products` (
  `category_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `products`
--

INSERT INTO `products` (`category_id`, `image`, `id`, `name`, `description`) VALUES
(3, 'crosstrainer2.jpg', 0, 'Life Fitness Crosstrainer E1 Go', 'De Life Fitness Crosstrainer E1 Go is de opvolger van de populaire Life Fitness Crosstrainer X1 go (Fit for Fun Crosstrainer Testwinnar 11/2013). De WhisperStride-technologie zorgt voor een vloeiende en geruisloze training. Ook de geringe pedaalafstand, de kleine stapbreedte en de grote staplengte zorgen voor een vloeiende en natuurlijke trainingsbeweging. Met 13 trainingsprogramma\'s, waarvan 5 hartslaggestuurd, en 20 weerstandsniveaus biedt de E1 Go een afwisselende en uitdagende training. Je hartslag kan je tijdens de training meten met de handsensoren op het ErgoGrip stuur van de crosstrainer of met een optioneel verkrijgbare borstband. De Go Console op de crosstrainer toont op een groot LCD-scherm overzichtelijk je belangrijke trainingsdata. De Go console is makkelijk te bedienen. Dankzij de duurzame en stabiele constructie gaat de crosstrainer lang mee. Voor extra comfort is hij uitgerust met een bidonhouder en worden transportwieltjes meegeleverd, zodat je de crosstrainer na de training makkelijk kan verplaatsen en ruimtebesparend op kan bergen.'),
(3, 'crosstrainer1.jpg', 1, 'cardiostrong crosstrainer EX60', 'De cardiostrong crosstrainer EX60 is perfect geschikt voor een aangename en gewrichtsvriendelijke cardiotraining. Vooral ouderen en mensen met gewrichtsproblemen of die moeten revalideren of herstellen van blessures, kunnen optimaal trainen met de cardiostrong crosstrainer EX60. De EX60 biedt een total body training en is uniek dankzij de twee vliegwielen. De crosstrainer kan optimaal aan de individuele lengte van de sporter worden aangepast en is zeer slijtbestendig en duurzaam. Dankzij de compacte afmetingen past de cardiostrong crosstrainer EX60 in vrijwel elke ruimte en is hij perfect geschikt voor thuisfitness.'),
(3, 'crosstrainer3.jpg', 2, 'cardiostrong Crosstrainer EX20', 'De cardiostrong EX20 Crosstrainer kenmerkt zich door zijn compacte formaat en eenvoudige bediening. Zo is bijvoorbeeld de maximale afstand tot de grond en het pedaal slechts 38 cm. Dit is ideaal wanneer lange mensen in een ruimte met een laag plafond willen trainen. De lengte van de pedaalarmen kan in 4 verschillende lengtes worden aangepast. Dit kan heel eenvoudig en snel gedaan worden met behulp van een draaiwieltje.'),
(3, 'crosstrainer4.jpg', 3, 'Flow Fitness X2i Crosstrainer', 'De Flow Fitness X2i Crosstrainer heeft maar liefst 69 weerstandniveaus zodat je intensief en effectief kan trainen. Dankzij het grote aantal trainingsprogramma\'s kan je afwisselend trainen en de Bluetooth-interface maakt de training een stuk leuker en motiverender. De crosstrainer biedt een gelijkmatige en soepele trainingsbeweging en een gewrichtsvriendelijke training. De Flow Fitness X2i Crosstrainer is geschikt voor beginnende en ervaren sporters en voor mensen die moeten revalideren of fysiotherapie volgen.'),
(3, 'crosstrainer5.jpg', 4, 'Taurus Crosstrainer FX9.9', 'De Taurus Crosstrainer FX9.9 is het nieuwste topmodel van Taurus! De crosstrainer is zowel geschikt voor semiprofessioneel als thuisgebruik. De crosstrainer biedt met 32 weerstandsniveaus en maar liefst 25 trainingsprogramma\'s een afwisselende en effectieve training en biedt dankzij het zware vliegwiel een soepele en gewrichtsvriendelijke trainingsbeweging. De Taurus Crosstrainer FX9.9 kan tot maar liefst 180 kg worden belast en biedt zowel beginnende als ervaren sporters (lengte 170 - 200 cm) een optimale cardiotraining.'),
(1, 'roeitrainer1.jpg', 5, 'Flow Fitness Glider DCT2500i Crosstrainer - Interactief Kinomap', 'Een extra grote, gepatenteerde dubbele tank is de drijvende kracht achter de krachtige Viking Pro XL indoor roeier, die een kolossale 65% grotere weerstand biedt dan standaard FDF horizontale modellen.'),
(1, 'roeitrainer2.jpg', 6, 'LifeFitness Roeitrainer Row HX', 'De Life Fitness houten roeitrainer Row HX combineert een strak design met hoge kwaliteit en duurzaamheid. Het model is uitgerust met een waterafstotend systeem en maakt indruk met zijn soepele, gewrichtsvriendelijke beweging. De waterweerstand is verstelbaar in 5 standen, de bluetooth-compatibele trainingscomputer spreekt voor zichzelf wat bediening betreft en de robuuste frameconstructie zorgt voor een stabiele houding. Perfect voor een effectieve full body workout.'),
(1, 'roeitrainer3.jpg', 7, 'Taurus Roeitrainer RX7', 'Op het droge zitten is onmogelijk een fijner gevoel dan zitten op de Taurus Roeitrainer RX7. De indoorrower met zijn hybride weerstandssysteem biedt een fijn roeigevoel bij hoge en lage intensiteit. Als één van de weinige waterrowers biedt de RX7 een bedieningspaneel aan in het midden van het handvat, zo kun je tijdens het trainen je instellingen veranderen.'),
(1, 'roeitrainer4.jpg', 8, 'Kettler Roeitrainer Rower H2O', 'De description is ideaal voor beginners en gevorderde gebruikers. Dankzij de waterdichtheid maakt de H2O indruk met zijn realistische roeigevoel en een prettige trekkracht. De gewatteerde zitting en de ergonomisch gevormde handgreep zorgen voor een comfortabele training.'),
(1, 'roeitrainer5.jpg', 9, 'First Degree Fitness Apollo Hybrid AR', 'De First Degree Fitness Apollo Hybrid AR Roeitrainer is een ideale roeitrainer voor thuisgebruik. De roeitrainer is makkelijk op te klappen. De waterweerstand zorgt voor een zeer natuurlijke weerstand. Met de dubbele rails is de glijbeweging zeer stabiel.'),
(1, 'roeitrainer6.jpg', 10, 'Darwin Roeitrainer RM50', 'De Darwin Roeitrainer RM50 is een gebruiksvriendelijke roeitrainer met een scherpe prijs-kwaliteitverhouding. De roeitrainer heeft een waterafstotend systeem en een verhoogde zitting. Dat maakt het op- en afstappen erg gemakkelijk.'),
(2, 'hometrainer1.jpg', 11, 'cardiostrong Ergometer Hometrainer BX70i', 'De cardiostrong Hometrainer BX70i is de meest gekozen hometrainer door fysiotherapeuten. De cardiostrong Ergometer Hometrainer BX70i is uitgerust met een inductierem, die zorgt voor een zeer precieze weerstandsinstelling en een aangename trainingsbeweging. Door de lage instap, het comfortabele zadel en de veelvuldig verstelbare zitpositie is ook comfort gegarandeerd bij regelmatig gebruik.'),
(2, 'hometrainer2.jpg', 12, 'cardiostrong hometrainer BX30 Plus', 'De cardiostrong Upright Bike BX30 Plus is de uitgebereide opvolger van de BX30. Met het grote bluetooth display, de 18 trainingsprogramma’s, een verwisselbaar zadel en het multipositiestuur wordt je training een stuk comfortabeler. De matzwarte look geeft de hometrainer een moderne uitstraling.'),
(2, 'hometrainer3.jpg', 13, 'Darwin Hometrainer HT40', 'De Darwin Hometrainer HT40 | Fiets Ergometer is een stijlvol beginnersmodel met een goede prijs-kwaliteitsverhouding. Dankzij de eenvoudige bediening en afwisselende trainingsprogramma\'s is training op de Darwin Hometrainer HT40 leuk en effectief.'),
(2, 'hometrainer4.jpg', 14, 'Flow Fitness DHT2500i Bluetooth Hometrainer', 'De Flow Fitness DHT2500i Bluetooth Hometrainer - Kinomap en iConsole is een compleet uitgeruste hometrainer. De hometrainer heeft 24 trainingsprogramma\'s en 32 weerstandsniveaus en kan worden gekoppeld met een smartphone of tablet. Je kan op het internet surfen, muziek luisteren of je favoriete film of serie kijken en gebruikmaken van de fitness-apps Kinomap en iConsole. De hometrainer heeft een lage instap en is daardoor geschikt voor herstel- en revalidatietraining en fysiotherapie. Zowel beginnende, ervaren als recreatiesporters kunnen optimaal met de Flow Fitness DHT2500i Bluetooth Hometrainer - Kinomap en iConsole trainen.'),
(2, 'hometrainer5.jpg', 15, 'Taurus ergometer UB9.9', 'Slecht weer, weinig tijd of sport je gewoon graag thuis en wil je fit blijven? Dan is de Taurus ergometer UB9.9 de juiste keuze voor jou: gebruiksvriendelijk, ruimtebesparend, comfortabel en een breed scala aan prestaties.'),
(2, 'hometrainer6.jpg', 16, 'Kettler Hometrainer Tour 400', 'De Kettler Hometrainer Tour 400 is ideaal voor amateursporters die thuis willen beginnen met trainen. De Kettler hometrainer Tour 400 heeft een goede ergonomie en gemakkelijke instelmogelijkheden. Door de lage instaphoogte stap je gemakkelijk en snel op en ga je direct aan de slag.'),
(4, 'loopband.jpg', 17, 'cardiostrong Loopband TX90 Smart', 'De cardiostrong Loopband TX90 Smart biedt zeer veel mogelijkheden voor de beginnende loper en ook voor de gevorderde loper. Trainen en entertainment tijdens het lopen, het kan allemaal! Handig is dat deze loopband ook compact opgeruimd kan worden door de inklapbare band en transportwieltjes.'),
(4, 'loopband2.jpg', 18, 'Darwin Fitness Loopband TM70 Touch', 'De Darwin Fitness Loopband TM70 Touch is een loopband met 49 vooraf ingestelde trainingsprogramma\'s en een groot en duidelijk display met touchscreenbediening.'),
(4, 'loopband3.jpg', 19, 'cardiostrong Loopband TX20', 'De cardiostrong TX20 is een compacte en betaalbare loopband op instapniveau om thuis wandel- en hardlooptrainingen te volgen. Omdat de loopband eenvoudig inklapbaar is en kleine afmetingen heeft kan hij zelfs in kleine fitnessruimtes en huiskamers gebruikt worden.'),
(4, 'loopband4.jpg', 20, 'Bowflex Loopband 56', 'Bowflex heeft met de BXT56 loopband een hoogwaardige loopband ontwikkeld die zorgt voor een natuurlijk hardloopgevoel in je eigen huis. Zowel de brede loopmat (152x56cm) als de buitengewone helling dragen bij aan een realistische loopervaring.'),
(4, 'loopband5.jpg', 21, 'cardiostrong Loopband TX30', 'De cardiostrong Loopband TX30 is perfect om aan de slag te gaan met hardlooptraining: Je zet hem snel in elkaar, hij is ruimtebesparend en gebruiksvriendelijk. De programmaselectie varieert van speciale programma\'s voor gewichtsverlies tot prestatiegerichte HIIT-programma\'s.'),
(4, 'loopband6.jpg', 22, 'Darwin Loopband TM30', 'De Darwin loopband TM30 vertegenwoordigt de volgende evolutie in loopbandtrainingen thuis. Het ingebouwde dempingssysteem beperkt de belasting van de gewrichten tot een minimum. De TM30 blinkt uit met een volledig nieuw inklapmechanisme: De loopband kan rechtop worden opgeborgen - met een diepte van slechts 31 cm!'),
(3, 'crosstrainer6.jpg', 23, 'Flow Fitness Glider DCT2500i Crosstrainer', 'De Flow Fitness Glider DCT2500i Crosstrainer - Interactief Kinomap is een solide crosstrainer met een groot aantal trainingsprogramma\'s en weerstandniveaus. Zowel beginners als ervaren sporters kunnen er effectief mee trainen. Dankzij de Bluetooth-interface kan je gebruikmaken van fitness-apps of je favoriete film of serie kijken en verveel je je geen moment! De crosstrainer heeft een soepel en gelijkmatig bewegingsverloop en gebogen armstangen en extra handgrepen. Je kan er effectief mee trainen en zal jarenlang plezier hebben van de Flow Fitness Glider DCT2500i Crosstrainer - Interactief Kinomap .');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `review`
--

CREATE TABLE `review` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `rating` int(11) NOT NULL,
  `description` text NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `name`, `role`) VALUES
(1, 'admin@healthone.com', '12345', 'Rick van Zon', 'admin');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `opening_times`
--
ALTER TABLE `opening_times`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catagoryid` (`category_id`);

--
-- Indexen voor tabel `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT voor een tabel `opening_times`
--
ALTER TABLE `opening_times`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT voor een tabel `review`
--
ALTER TABLE `review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Beperkingen voor tabel `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
